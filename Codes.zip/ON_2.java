// Source: https://www.geeksforgeeks.org/understanding-time-complexity-simple-examples/

class ON_2 {
 
    public static void main(String[] args)
    {
        int i, n = 8;
        for (i = 1; i <= n; i++) {
            System.out.printf("Hello World !!!\n");
        }
    }
}
