import java.lang.*;

class ON_4
{
    public static void main (String[] args)
    {   
       
      // Creating an integer array
      // named arr of size 10.
      int[] arr = new int[]{0,1,2,3,4,5,6,7,8,9};
       
      Boolean flag = false;
    
    for(int i = 1; i<=10; i++)
    {
        if(arr[i] == 2)
        {
            flag = true;
        }
    }  
           
    }
}